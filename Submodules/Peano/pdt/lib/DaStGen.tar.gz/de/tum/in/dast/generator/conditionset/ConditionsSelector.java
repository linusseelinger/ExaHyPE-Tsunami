// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.conditionset;

import java.util.HashSet;
import java.util.Set;

import de.tum.in.dast.analysis.DepthFirstAdapter;
import de.tum.in.dast.node.AConditionalIfInnerDeclarations;
import de.tum.in.dast.node.AConditionalIfOuterDeclarations;
import de.tum.in.dast.node.AConditionalIfnInnerDeclarations;
import de.tum.in.dast.node.AConditionalIfnOuterDeclarations;
import de.tum.in.dast.util.SetUtils;


/**
 * Conditions Analyser 
 * 
 * This visitor runs over the AST and tracks all the ifdefs and ifndefs within
 * the file. These conditionals are stored within a set and the power set of 
 * this set then gives you the information which variants of a datastructure
 * have to be created.
 *
 * @author Tobias Weinzierl, Wolfgang Eckhardt
 */
public class ConditionsSelector extends DepthFirstAdapter {
  /**
   * Throughout the traversal, we only store the ifdef-identifiers. The 
   * powerset with ifdefs and ifndefs is created afterwards by 
   * getPowerSetOfConditions().
   */
  private Set<String> conditions = new HashSet<String>();

  @Override
  public void inAConditionalIfInnerDeclarations(AConditionalIfInnerDeclarations node) {
	  conditions.add( node.getIdentifier().getText() );	  
  }
  
  @Override
  public void inAConditionalIfnInnerDeclarations(AConditionalIfnInnerDeclarations node) {
	  conditions.add( node.getIdentifier().getText() );	  
  }
  
  @Override
  public void inAConditionalIfOuterDeclarations(AConditionalIfOuterDeclarations node) {
	  conditions.add( node.getIdentifier().getText() );	  
  }
  
  @Override
  public void inAConditionalIfnOuterDeclarations(AConditionalIfnOuterDeclarations node) {
	  conditions.add( node.getIdentifier().getText() );	  
  }
 

  /**
   * Get set of all possible combinations.
   */
  public Set<Set<Conditional>> getPowerSetOfConditions() {
	Set<Set<Conditional>> result = new HashSet<Set<Conditional>>();
	
	Set<Set<String>> ifdefsSwitchedOn = SetUtils.powerSetWithoutEmptyElement(new HashSet<String>(conditions));
	ifdefsSwitchedOn.add(new HashSet<String>());

	for (Set<String> currentSwitchedOn: ifdefsSwitchedOn) {
	  Set<Conditional> newEntry = new HashSet<Conditional>();
	  for (String ifdef: conditions) {
        if ( currentSwitchedOn.contains(ifdef) ) {
          newEntry.add( new Conditional(ifdef,Conditional.Type.IfDefined) );
        }
        else {
          newEntry.add( new Conditional(ifdef,Conditional.Type.IfNotDefined) );
        }
	  }
	  result.add( newEntry );
	}
	
    return result;
  }
 
}
