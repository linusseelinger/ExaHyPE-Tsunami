// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.naming;

import de.tum.in.dast.generator.DastGenAST.Type;

public class TinyVectorType extends Type {

	private String length;
	
	public TinyVectorType(Type type, String length) {
		super(type);
		this.length = length;
	}
	
	
	public String getTypeString(boolean qualified) {
		return "tarch::la::Vector<" + length 
		       + "," + super.getTypeString(qualified) + ">";
	}

}
