// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.memberSelection;

import de.tum.in.dast.generator.DastGenAST.Size;
import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.generator.mapper.Mapper;
import de.tum.in.dast.generator.mapper.MapperFactory;
import de.tum.in.dast.generator.mapper.SimpleMapper;
import de.tum.in.dast.util.DaStStringBuilder;

/**
 * An object of this class represents a declaration of a member in the 
 * datastructure declaration. These objects are initialized by the 
 * MemberSelector and afterwards enriched with data which is needed to 
 * generate valid code.
 * 
 * Thus, members just contain data. The code generated is determined by 
 * a members mapper.
 * 
 * Members are Comparable. They can be sorted to reflect the order in which
 * they are declared in the generated header file.
 * 
 * @author Wolfgang Eckhardt
 * @author Tobias Weinzierl
 */
public class Member implements Comparable<Member> {
	
	// TODO introduce method, which returns the qualified member name to
	// simplify the mappers
	// TODO allow constructs like 2 * DIM as array_length?
	
	// the mapper of this member TODO make it private again
	protected Mapper mapper; 
	// the variable, the member is mapped to. I.e. if it is a "real" member,
	// or mapped to the field packed_records
	protected String mappedVariable; 
	// the name of the member as declared in the declaration file
	protected String memberName;
	// the type of the member, e.g. "int"
	protected String type;
	//the qualified classname  
	protected String className;
	// was this member declared persistent?
	protected boolean persistent = false;
	// was this member declared to be an array?
	protected Size arraySize = null;
	// was it declared to be parallelized?
	protected boolean isParallel = false;

	protected boolean isExposed = false;
	
	public Member(String memberName, String type) {
		super();
		this.memberName = memberName;
		this.mappedVariable = memberName;
		this.type = type;
		// assign per default a simple mapper
		this.mapper = new SimpleMapper(this, new Type(type, "")); 
	}
	
	public Member clone() {
		Member retVal = new Member(this.memberName, this.type);
		retVal.mappedVariable = new String(this.mappedVariable);
		if (this.className != null) {
			retVal.className = new String(this.className);
		}
		retVal.persistent = this.persistent;
		retVal.arraySize  = this.arraySize;
		retVal.isParallel = this.isParallel;
		retVal.isExposed  = this.isExposed;
		
		// TODO it's not right to assign mappers instead of cloning! 
		retVal.mapper = MapperFactory.getInstance().getMapperForMember(retVal, this.mapper.getTypeObject());

		return retVal;
	}

	/**
	 * @return the name of the variable this member is 
	 * 			mapped to, obeying the rules of the nametranslator 
	 */
	public String getMappedVariable() {
		return mappedVariable;
	}

	public void setMappedVariable(String mappedVariable) {
		this.mappedVariable = mappedVariable;
	}	
	
	public String getMemberName() {
		return memberName;
	}

	public String getType() {
		return type;
	}
	
	public boolean isPacked() {
		return false;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}
	

	public boolean isPersistent() {
		return persistent;
	}

	public void setPersistent(boolean persistent) {
		this.persistent = persistent;
	}

	public boolean isExposed() {
	  return isExposed;
	}
	
	public void setExposed(boolean isExposed) {
	  this.isExposed = isExposed;
	}
	
	public boolean isParallel() {
		return isParallel;
	}
	
	public void setParallel(boolean isParallel) {
		this.isParallel = isParallel;
	}

	/**
	 * @return a Size-Object, if this member is an array
	 *         otherwise it returns null
	 */
	public Size getArraySize() {
		return arraySize;
	}

	public void setArraySize(Size arraySize) {
		this.arraySize = arraySize;
	}
	
	public void setMapper(Mapper mapper) {
		this.mapper = mapper;
	}
	
/** Delegate Methods  **/
	
	public void generateGetterSetterSignatures(DaStStringBuilder builder) {
		mapper.writeMethodSignature(0,builder);
        builder.indent(2);
        mapper.writeMethodSignature(1,builder);
        builder.indent(2);
	}
	
	public void generateGetterSetterMethods(DaStStringBuilder builder) {
		mapper.writeMethodImplementation(0,builder);
        builder.indent(2);
        mapper.writeMethodImplementation(1,builder);
        builder.indent(2);
	}
	
	
	public void generateMethodSignatures(DaStStringBuilder builder){
      for (int i=0; i<mapper.getNumberOfOperations(); i++) {
	    mapper.writeMethodSignature(i, builder);
        builder.indent(2);
      }
	}
	
    public void generateMethodImplementations(DaStStringBuilder builder){
     
    	for (int i=0; i<mapper.getNumberOfOperations(); i++) {
    		mapper.writeMethodImplementation(i,builder);
    		builder.indent(2);
    	}
	}
    

    /**
     * Write the c++-declaration of this member to the stringbuilder
     * 
     * The operation is used both for the discarded attributes and the 
     * persistent attributes. However, the persistent attributes are 
     * already a struct, i.e. visible, so we may not change the visibility
     * here. 
     */
    public void writeDeclaration(DaStStringBuilder builder, boolean currentClassIsPacked) {
      if (isExposed && !isPersistent() && !currentClassIsPacked) {
        builder.appendAndIndent("public:\n");
        mapper.writeDeclaration(builder,currentClassIsPacked);
        builder.appendAndIndent("private:\n");
      }
      else {
        mapper.writeDeclaration(builder,currentClassIsPacked);
      }
    }
    
    /**
     * write any assertions, which have to be placed in the constructor of 
     * the generated data type
     */
    public void writeConstructorAsserts(DaStStringBuilder builder) {
    	mapper.writeConstructorAssertions(builder);
    }

  public boolean passObjectsInConstructorViaConstReference() {
  	return mapper.passObjectsInConstructorViaConstReference();
  }
    
	public String getToString() {
		return mapper.getToString();
	}

	public String getMappedType() {
		return mapper.getMappedDataType();
	}

	@Override
	public int hashCode() {
		final int PRIME = 31;
		int result = 1;
		result = PRIME * result + ((arraySize == null) ? 0 : arraySize.hashCode());
		result = PRIME * result + ((className == null) ? 0 : className.hashCode());
		result = PRIME * result + ((mappedVariable == null) ? 0 : mappedVariable.hashCode());
		result = PRIME * result + ((mapper == null) ? 0 : mapper.hashCode());
		result = PRIME * result + ((memberName == null) ? 0 : memberName.hashCode());
		result = PRIME * result + (persistent ? 1231 : 1237);
		result = PRIME * result + ((type == null) ? 0 : type.hashCode());
		return result;
	}

	
	/**
	 * autogenerated equals-method by eclipse
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		final Member other = (Member) obj;
		if (arraySize == null) {
			if (other.arraySize != null)
				return false;
		} else if (!arraySize.equals(other.arraySize))
			return false;
		if (className == null) {
			if (other.className != null)
				return false;
		} else if (!className.equals(other.className))
			return false;
		if (mappedVariable == null) {
			if (other.mappedVariable != null)
				return false;
		} else if (!mappedVariable.equals(other.mappedVariable))
			return false;
		if (memberName == null) {
			if (other.memberName != null)
				return false;
		} else if (!memberName.equals(other.memberName))
			return false;
		if (persistent != other.persistent)
			return false;
		if (type == null) {
			if (other.type != null)
				return false;
		} else if (!type.equals(other.type)) {
			return false;
		}
		return true;
	}

	
/**
 * Members are sortable for parallelization via MPI:
 * MPI needs variable declarations in ascending order of their physical address.
 * Persistent Members as elements of struct PersistentRecords are declared first, 
 * thus they have to be given to MPI first.
 */
	public int compareTo(Member other) {		
		int myState = getState(this);
		int otherState = getState(other);
		int retval =  otherState - myState;
		return retval;
	}
	
	private int getState(Member member) {
		int result = 0;
		
		if (member.isPersistent()) {
			result = 1;
		}
		
		return result;
	}
	
	@Override
	public String toString() {
		return "( Class: " + className + " Member: name " + memberName + " Type: " + type + " Mapper.type: " + mapper.toString() + 
		       " MappedVariable: " + mappedVariable + " packed: "+isPacked()+" isParallel: "+ isParallel+ " isPersistent: "+ isPersistent() 
		       + " ArraySize: " + arraySize + " Expose: " + isExposed + ")";
	}

	public Mapper getMapper() {
		return mapper;
	}
}
