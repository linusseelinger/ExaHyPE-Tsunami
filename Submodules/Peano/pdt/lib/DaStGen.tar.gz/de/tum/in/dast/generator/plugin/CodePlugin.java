// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.plugin;

import java.util.List;

import de.tum.in.dast.generator.DaStConfiguration;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.util.DaStStringBuilder;

/**
 * Interface for classes which want to plugin into code generation.
 * CodePlugins are given the possibility to add methods and variables
 * to the definition and implementation of classes to the end of the 
 * process of codegeneration.
 * 
 * Parameters for each method are the qualified className 
 * (e.g. test::namespace::DummyClass ) as well as the DaStStringBuilder,
 * the output must be generated to.
 * Furthermore, a plugin is passed a configuration object, containing some 
 * configuration settings and the current state of the code generation process.
 * 
 * @author Wolfgang Eckhardt
 *
 */
public interface CodePlugin {
	public void generateDefinition(DaStConfiguration configuration,
			DaStStringBuilder stringBuilder, String qualifiedClassName, 
			List<Member> virtualMembers, List<Member> internalMembers);

	
	public void generateImplementation(DaStConfiguration configuration, 
			DaStStringBuilder stringBuilder, String qualifiedClassName, 
			List<Member> virtualMembers, List<Member> internalMembers);

	
}
