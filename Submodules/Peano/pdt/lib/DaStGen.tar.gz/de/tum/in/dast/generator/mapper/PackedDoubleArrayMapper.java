// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.mapper;

import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.generator.naming.NameTranslatorFactory;
import de.tum.in.dast.util.DaStStringBuilder;

public class PackedDoubleArrayMapper extends ArrayMapper {

	public PackedDoubleArrayMapper(Member member, Type type) {
		super(member, type);
	}
	
	@Override
	public void writeDeclaration(DaStStringBuilder builder, boolean currentClassIsPacked) {
		builder.append("short int "
				+translator.getAttributeName(member.getMemberName()+"[" +
						member.getArraySize().getStringRepresentation() + "];"));
		builder.decrementAndIndent(getClass().getName());
	}
	
	@Override
	protected void getGetMethodBody(DaStStringBuilder builder) {
		
		String resultName = "result";
		if (type.needsInitialization()) {
			resultName = type.getInitialization(resultName);
		}
		builder.appendAndIndent(type.getTypeString(false) + " " + resultName + ";");
		
		builder.append("for (int i = 0; i < " + member.getArraySize().getStringRepresentation() + "; i++) {");
		builder.incrementAndIndent(getClass().getName());
		builder.append("result[i] = " + 
				translator.getGetter(member.getMemberName()	+ "(i);"));
		builder.decrementAndIndent(getClass().getName());
		builder.appendAndIndent("}");
		builder.append("return result;");
	}
	
	
	@Override
	protected void getSetMethodBody(DaStStringBuilder builder) {
		builder.append("for (int i = 0; i < " + member.getArraySize().getStringRepresentation() 
				+ "; i++) {");
		builder.incrementAndIndent(getClass().getName());
		builder.append(translator.getSetter(member.getMemberName() + "(i, "
				+ translator.getArgumentName(member.getMemberName()+"[i]);")));
		builder.decrementAndIndent(getClass().getName());
		builder.append("}");
	}
	
	@Override
	protected void getSetElementMethodBody(DaStStringBuilder builder) {
		builder.indent();
		writeElementAccessAssertions(builder);
	
		// create the temporary memory and copy the memory.
		//int tmp = 0;
	    //char* double_ptr = reinterpret_cast<char*> (&val) + 4; // set to upper "int"
	    //char* int_ptr = reinterpret_cast<char*> (&tmp);
		builder.appendAndIndent("int tmp = 0;");
		builder.appendAndIndent("const char* double_ptr = reinterpret_cast<const char*> (&"
				+ translator.getArgumentName(member.getMemberName()) + ") + 4;");
		builder.appendAndIndent("char* int_ptr = reinterpret_cast<char*> (&tmp);");
		
		// copy the bytes
		builder.appendAndIndent("*int_ptr = *double_ptr;");
		builder.appendAndIndent("*(int_ptr + 1) = *(double_ptr + 1);");
		builder.appendAndIndent("*(int_ptr + 2) = *(double_ptr + 2);");
		builder.appendAndIndent("*(int_ptr + 3) = *(double_ptr + 3);");
		
		// tmp = tmp >> 12;
		builder.appendAndIndent("tmp = tmp >> 12;");
	    builder.indent();
		// last 8 bits of tmp (representing the MSBs of the fraction) are the last 8 bits of 
		// our reduced accuracy value 
		// short int save =  tmp & 0xff;
		
		String memberName = member.getMappedVariable();
		builder.appendAndIndent(memberName +"[elementIndex] = tmp & 0xff;");
		
		// extract the exponent
		// int exp = (tmp & 0x007ff00) >> 8;
		
		builder.appendAndIndent("short int exponent = (tmp & 0x0007ff00) >> 8;");
		
		// correct the bias
		// exp = exp - 1023 + 63;
		
		builder.appendAndIndent("exponent = exponent - 1023 + 63;");
		// save |= exp << 8;
		
		builder.appendAndIndent(memberName + "[elementIndex] |= (exponent << 8);");
		
		// save |= (tmp >> 4) & 0x8000;
		
		builder.appendAndIndent(memberName + "[elementIndex] |= (tmp >> 4) & 0x8000;");
	}
	
	@Override
	protected void getGetElementMethodBody(DaStStringBuilder builder) {
		builder.indent();
		writeElementAccessAssertions(builder);
		
		String memberName = member.getMappedVariable();
	
		// create the memory for the creation of the return value
		builder.appendAndIndent("int tmp = 0;");
		
		// extract the sign and shift it to its possition
		//  tmp |= ((save & 0x8000) << 16);
		builder.appendAndIndent("tmp |= ((" + memberName + "[elementIndex] & 0x8000) << 16);");
		
		// extract the exponent, correct the bias, and set it 
		// int exponent = ((save & 0x7f00) >> 8);
		// exponent = exponent - 63 + 1023;
		// tmp |= (exponent << 20); 
	
		builder.appendAndIndent("int exponent = ((" + memberName + "[elementIndex] & 0x7f00) >> 8);");
		builder.appendAndIndent("exponent = exponent - 63 + 1023;");
		builder.appendAndIndent("tmp |= (exponent << 20);");
		
		// set the mantissa 
		// tmp = ((save & 0x00ff) << 12);
		builder.appendAndIndent("tmp |= ((" + memberName + "[elementIndex] & 0x00ff) << 12);");
		
		// create the return value and copy memory 
		// char* double_ptr = reinterpret_cast<char*> (&result) + 4; // set to upper "int"
	    // char* int_ptr = reinterpret_cast<char*> (&tmp);
	    // for (int i = 0; i < 4; i++)
	    //   {
	    //     *double_ptr = *int_ptr;
	    //     int_ptr++;
	    //     double_ptr++;
	    //   }
		builder.appendAndIndent("double result = 0;");
		builder.appendAndIndent("char* double_ptr = reinterpret_cast<char*> (&result) + 4;");
		builder.appendAndIndent("char* int_ptr = reinterpret_cast<char*> (&tmp);");
		builder.appendAndIndent("*double_ptr = *int_ptr;");
		builder.appendAndIndent("*(double_ptr + 1) = *(int_ptr + 1);");
		builder.appendAndIndent("*(double_ptr + 2) = *(int_ptr + 2);");
		builder.appendAndIndent("*(double_ptr + 3) = *(int_ptr + 3);");
		builder.indent();
		builder.appendAndIndent("return result;");
	}

	public void writeConstructorAssertions(DaStStringBuilder builder) {
		builder.appendAndIndent(NameTranslatorFactory.getNameTranslator().getAssertion()
				+ "((sizeof(short int) >= 2));");
		builder.appendAndIndent(NameTranslatorFactory.getNameTranslator().getAssertion()
				+ "((sizeof(double) == 8));");
	}

	

	
	@Override
  public boolean passObjectsInConstructorViaConstReference() {
  	return true;
  }
}
