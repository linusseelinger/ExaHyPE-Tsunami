// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.conditionset;

/**
 * Represents one ifdef or ifndef Statement
 *  
 * @author Tobias Weinzierl
 */
public class Conditional {
  public enum Type {
	 IfDefined, IfNotDefined
  }

  private String _name;
  private Type   _type;
  
  public Conditional(String name, Type type) {
    _name = name;
    _type = type;
  }
  
  public String getStringRepresentation() {
    if (_type==Type.IfDefined) {
      return "defined(" + _name + ")";
    }
    else {
      return "!defined(" + _name + ")";
    }
  }
  
  public String toString() {
    if (_type==Type.IfDefined) {
      return "(defined," + _name + ")";
    }
    else {
      return "(undefined," + _name + ")";
    }
  }
  
  public boolean equals(Object obj) {
	return (obj instanceof Conditional) && ((Conditional)obj)._name.equals(_name) && ((Conditional)obj)._type==_type;
  }
  
  public int hashCode() {
	int result = _name.hashCode();
	if (_type==Type.IfDefined) result++;
	return result;
  }
}
