package de.tum.in.dast.generator.mapper;

import de.tum.in.dast.generator.DaStConfiguration;
import de.tum.in.dast.generator.DastGenAST.Size;
import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.generator.naming.NameTranslator;
import de.tum.in.dast.generator.naming.NameTranslatorFactory;
import de.tum.in.dast.util.DaStStringBuilder;


/**
 * Pointer Mapper
 * 
 * A pointer is a void* and internally can also be seen as MPI_UNSIGNED_LONG.
 * 
 * @author Tobias Weinzierl
 */
public class PointerMapper implements Mapper {

  protected Member member;
  protected NameTranslator translator = NameTranslatorFactory.getNameTranslator();
  protected Type type;

  public PointerMapper(Member member, Type type) {
    this.member = member;
    this.type = type;
  }
  
  @Override
  public int getNumberOfOperations() {
    return 2;
  }

  @Override
  public void writeMethodSignature(
    int operationNumber,
    DaStStringBuilder builder
  ) {
    switch (operationNumber) {
    case 0:
      builder.append( getGetMethodSignature(false) );
      builder.append( ";" );
      break;
    case 1:
      builder.append( getSetMethodSignature(false) );
      builder.append( ";" );
      break;
    default: throw new RuntimeException( "Only operation 0-1 supported" );
  }
  }

  @Override
  public void writeMethodImplementation(int operationNumber,
      DaStStringBuilder builder) {
    switch (operationNumber) {
    case 0:
      getGetMethod(builder);
      break;
    case 1:
      getSetMethod(builder);
      break;
    default: throw new RuntimeException( "Only operation 0-1 supported" );
  }
  }

  @Override
  public void writeDeclaration(
    DaStStringBuilder builder,
    boolean currentClassIsPacked
  ) {
    builder.appendAndIndent(
      "void* "
      +translator.getAttributeName(member.getMemberName())
      +";"
    );
  }

  @Override
  public String getMappedDataType() {
    return "void*";
  }

  @Override
  public String getToString() {
    return "out << \""+member.getMemberName()+":\" << "
         + translator.getGetter(member.getMemberName())+"();";
  }

  @Override
  public Size getBitfieldLength() {
    return new Size(0);
  }

  @Override
  public Type getTypeObject() {
    return type;
  }

  @Override
  public void writeConstructorAssertions(DaStStringBuilder builder) {
    // No assertions to insert - do nothing.
  }

  @Override
  public String toString() {
    return getClass().getName();
  }
  
  private void getGetMethod(DaStStringBuilder builder) {
    builder.indent();
    builder.append(getGetMethodSignature(!DaStConfiguration.manuallyInline));
    builder.append(" {");
    builder.incrementAndIndent(getClass().getName());
    builder.append("return "+member.getMappedVariable()+";" );
    builder.decrementAndIndent(getClass().getName());
    builder.appendAndIndent("}");
  }

  private void getSetMethod(DaStStringBuilder builder) {
    builder.indent();
    builder.append(getSetMethodSignature(!DaStConfiguration.manuallyInline));
    builder.append(" {");
    builder.incrementAndIndent(getClass().getName());
    builder.append(member.getMappedVariable()+" = " + translator.getArgumentName(member.getMemberName()) + ";" );
    builder.decrementAndIndent(getClass().getName());
    builder.appendAndIndent("}");
  }

  private String getSetMethodSignature(boolean qualified) {
    String prefix             = "";
    String qualifiedClassName = "";
    String attributes         = "";
    if (DaStConfiguration.manuallyInline) {
      prefix += "inline";
    }
    if (qualified) {
      qualifiedClassName = member.getClassName() + "::";
    }
    if (DaStConfiguration.manuallyInline) {
      attributes += AttributeInline;
    }
    return prefix + " void " + qualifiedClassName + 
      translator.getSetter(member.getMemberName()) + 
      "(void* "+
      translator.getArgumentName(member.getMemberName())+") " + attributes;
  }

  private String getGetMethodSignature(boolean qualified) {
    String prefix             = "";
    String qualifiedClassName = "";
    String attributes         = "";
    if (DaStConfiguration.manuallyInline) {
      prefix += "inline";
    }
    if (qualified) {
      qualifiedClassName = member.getClassName() + "::";
    }
    if (DaStConfiguration.manuallyInline) {
      attributes += AttributeInline;
    }
    return prefix + " void* " + qualifiedClassName +
        translator.getGetter(member.getMemberName())+"() const " + attributes;
  }


	
	@Override
  public boolean passObjectsInConstructorViaConstReference() {
  	return false;
  }
}
