// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.DastGenAST;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;

import de.tum.in.dast.generator.conditionset.Conditional;

public class Ifdef implements AbstractNode, AbstractNodeContainer {

	private ArrayList<Conditional> conditions = new ArrayList<Conditional>(); 
	
	private LinkedList<AbstractNode> childNodes = new LinkedList<AbstractNode>();
	
	public Ifdef(Conditional condition) {
		conditions.add(condition);
	}
	
	public Ifdef(Collection<Conditional> conditions) {
		this.conditions.addAll(conditions);
	}
	
	public void applyVisitor(Visitor visitor) {
		visitor.process(this);
	}
	
	public void addChildNodeFront(AbstractNode node) {
		childNodes.addFirst(node);
	}
	
	public void addChildNodeEnd(AbstractNode node) {
		childNodes.add(node);
	}

	public LinkedList<AbstractNode> getChildNodes() {
		return childNodes;
	}
	
	public ArrayList<Conditional> getConditions() {
		return conditions;
	}
}
