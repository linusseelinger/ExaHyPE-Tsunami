// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator;

import java.util.ArrayList;
import java.util.Collection;
import java.util.LinkedList;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

import de.tum.in.dast.generator.DastGenAST.MetadataSelector;
import de.tum.in.dast.generator.DastGenAST.Size;
import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.generator.conditionset.Conditional;
import de.tum.in.dast.node.AArrayDeclarator;
import de.tum.in.dast.node.AClassDeclaration;
import de.tum.in.dast.node.AClassheader;
import de.tum.in.dast.node.AConditionalIfOuterDeclarations;
import de.tum.in.dast.node.AConditionalIfnOuterDeclarations;
import de.tum.in.dast.node.ADeclaration;
import de.tum.in.dast.node.ADiscardPersist;
import de.tum.in.dast.node.AEnumDeclaration;
import de.tum.in.dast.node.AEnumTypeSpecifier;
import de.tum.in.dast.node.AExtendOuterDeclaration;
import de.tum.in.dast.node.AExtendsStatement;
import de.tum.in.dast.node.AIdentifierDeclarator;
import de.tum.in.dast.node.AIncludeOuterDeclaration;
import de.tum.in.dast.node.AIncludeStatement;
import de.tum.in.dast.node.AMemberDeclaration;
import de.tum.in.dast.node.APackedTypeDeclaration;
import de.tum.in.dast.node.AParamArrayDimension;
import de.tum.in.dast.node.APersistentPersist;
import de.tum.in.dast.node.Start;
import de.tum.in.dast.node.TPacked;

/**
 * 
 * Performs semantic analysis. At the moment checked issues:
 * - variable names that are declared more times
 * - types that aren't declared, but should be declared as enums
 * - missing persistence keywords
 * - checks Constant type declaration before use, along with size-hints 
 * - include-statements not in #ifdefs
 * 
 * @author Wolfgang Eckhardt
 * 
 */
public class Validator extends ConditionalDepthFirstAdapter {

	/** Collection containing all the declared <code> enums <code> 
	 *  of the syntax tree */
	private Collection<String> enumerations = new ArrayList<String>();
	
	/** 
	 * Collection containing all the <code> declarators <code>
	 *  in the syntax tree */
	private Collection<String> declarators = new ArrayList<String>();

	/**
	 * Collection containing all declared constants	 */
//	private Collection<String> constants = new ArrayList<String>();
	
	/** flag indicating, if a <code> persist <code>  - node was found 
	 * in a memberDeclaration, i.e. if the member has a persistence key word */ 
	private boolean persistenceDeclarationFound = false;
	
	/**
	 * flag indicating, if a packed type is declared
	 */
	private boolean packedTypeDeclarationFound = false;

	private Type packedFieldType = null;
	
	private Map<String, Size> constantSizes = new TreeMap<String, Size>();
	
	/**
	 * @param selectedConditions the conditions which should be checked
	 * 							 ( so a kind of white list)
	 */
	public Validator(Set<Conditional> selectedConditions) {
		super(selectedConditions);
	}
	
	public void validate(LinkedList<Start> trees) {
		MetadataSelector mds = new MetadataSelector(selectedConditions);
		mds.selectMetadata(trees);
		this.packedFieldType = mds.getPackedFieldType();
		this.constantSizes = mds.getConstantSizes();
		for (Start ast: trees) {
				ast.apply(this);
		}
	}
	
	/*************************************************/
	/****     Check for not declared constants     ***/
	/*************************************************/
	
//	@Override
//	public void inAParamArrayDimension(AParamArrayDimension node) {
//		String constant = node.getIdentifier().getText();
//		if (!constants.contains(constant)) {
//			int line = node.getIdentifier().getLine();
//			throw new RuntimeException("Class "+qualifiedClassName+" Line "+line+": Constant " + constant + " not declared!");
//		}
//	}
	
	
	/***************************************************/ 
	/****    Checks for undeclared types (enums?)   ****/
	/***************************************************/

	
	@Override
	public void inAEnumDeclaration(AEnumDeclaration node) {
//		System.out.println("Enum declared: "+node.getIdentifier().getText());
		enumerations.add(node.getIdentifier().getText()); 
	}
	

	@Override
	public void inAEnumTypeSpecifier(AEnumTypeSpecifier node) {
		String identifier = node.getIdentifier().getText();
		if (!enumerations.contains(identifier)) {
			int line = node.getIdentifier().getLine();
			throw new RuntimeException("Class "+qualifiedClassName+" Line "+line+": Identifier " + identifier + " not declared as enum or no known type!");
		}
	}

	/************************************************/ 
	/****    Checks for redeclared identifiers   ****/
	/************************************************/

	@Override
	public void inAArrayDeclarator(AArrayDeclarator node) {
		String identifierName = node.getIdentifier().getText();
		if (declarators.contains(identifierName)) {
			int line = node.getIdentifier().getLine();
			System.err.println( "warning: Class "+qualifiedClassName+" Line "+line+": Identifier: "+identifierName+" declared twice!" );
		}
		declarators.add(identifierName);
	}


	@Override
	public void inAIdentifierDeclarator(AIdentifierDeclarator node) {
		String identifierName = node.getIdentifier().getText();
		if (declarators.contains(identifierName)) {
			int line = node.getIdentifier().getLine();
			System.err.println( "warning: Class "+qualifiedClassName+" Line "+line+": Identifier: "+identifierName+" declared twice!" );
		}
		declarators.add(identifierName);
	}

	
	/******************************************************/ 
	/****    Checks for missing persistence-keywords    ****/
	/******************************************************/
	
	@Override
    public void inAMemberDeclaration(AMemberDeclaration node) {
    	persistenceDeclarationFound = false;
    }
	
	@Override
    public void outAMemberDeclaration(AMemberDeclaration node) {
		if (!persistenceDeclarationFound) {
			int line = node.getSemicolon().getLine();
    		throw new RuntimeException("Class "+qualifiedClassName+" Line "+line+": No persistence keyword found for: "+node);
    	}
    }
    
	@Override
    public void inADiscardPersist(ADiscardPersist node) {
		if (persistenceDeclarationFound) {
			int line = node.getDiscard().getLine();
			throw new RuntimeException("Class "+qualifiedClassName+" Line "+line+": Dublicate persistence declaration for: "+node);
		}
    	persistenceDeclarationFound = true;
    }

	@Override
	public void inAPersistentPersist(APersistentPersist node) {
		persistenceDeclarationFound = true;
	}
	
	/**********************************************************/
	/**   Check for packed-Type declaration if packed is used */
	/**********************************************************/
	
	@Override
	public void inAPackedTypeDeclaration(APackedTypeDeclaration node) {
		if (packedTypeDeclarationFound) {
			int line = node.getSemicolon().getLine();
			throw new RuntimeException("Class "+qualifiedClassName+" Line "+line+": Redeclaration of Packed-Type");
		}
		packedTypeDeclarationFound = true;
	}
	
	
	@Override
	public void caseTPacked(TPacked node) {
		if (packedFieldType == null) {
			int line = node.getLine();
			throw new RuntimeException("Class "+qualifiedClassName+" Line "+line+": keyword 'packed' used, but " +
					"no Packed-Type declared!\n" +
					"ifdef-branch: " + selectedConditions);
		}
	}
	
	@Override
	public void inAParamArrayDimension(AParamArrayDimension node) {
		String constant = node.getIdentifier().getText();
		Size arraySize = constantSizes.get(constant);
		// constants have to be declared previously
		if (arraySize == null) {
			int line = node.getIdentifier().getLine();
			throw new RuntimeException("Class "+qualifiedClassName+" Line "+line+": Constant " + constant + " not declared!");
		}
	}
	
	/********************************************************************/
	/**   Check include and extend statements not embedded in #ifdefs  **/
	/********************************************************************/
	
	  @Override
	  public void inAIncludeOuterDeclaration(AIncludeOuterDeclaration node) {
		  if (node.parent() instanceof AConditionalIfOuterDeclarations
				  || node.parent() instanceof AConditionalIfnOuterDeclarations) {
			  int line = ((AIncludeStatement)node.getIncludeStatement()).getInclude().getLine();
				throw new RuntimeException("Class "+qualifiedClassName+" Line "+line+": " +
						"Include-Statements may not be nested in \"#ifdef\" or \"#ifndef\"");
		  }
	  }

	  @Override
	  public void inAExtendOuterDeclaration(AExtendOuterDeclaration node) {
		  if (node.parent() instanceof AConditionalIfOuterDeclarations
				  || node.parent() instanceof AConditionalIfnOuterDeclarations) {
			  int line = ((AExtendsStatement)node.getExtendsStatement()).getExtends().getLine();
				throw new RuntimeException("Class "+qualifiedClassName+" Line "+line+": " +
						"Extends-Statements may not be nested in \"#ifdef\" or \"#ifndef\"");
		  }
	  }
	
	/**********************************************************/
	/**   get the classname of the checked class */
	/**********************************************************/

	private String qualifiedClassName = "";
    
    @Override
    public void inStart(Start node) {
    	AClassDeclaration classDeclaration = 
    		(AClassDeclaration) ((ADeclaration)node.getPDeclaration()).getClassDeclaration();
    	qualifiedClassName = ((AClassheader)classDeclaration.getClassheader()).getClassname().toString();
    	qualifiedClassName = qualifiedClassName.replaceFirst("class ", "");
    }
}
