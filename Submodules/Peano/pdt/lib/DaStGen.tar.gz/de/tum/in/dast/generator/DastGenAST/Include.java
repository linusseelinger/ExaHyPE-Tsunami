// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.DastGenAST;

public class Include implements AbstractNode {

	private String include;
	
	public Include(String include) {
		this.include = include;
	}
	
	public void applyVisitor(Visitor visitor) {
		visitor.process(this);
	}
	
	public String getInclude() {
		return include;
	}

}
