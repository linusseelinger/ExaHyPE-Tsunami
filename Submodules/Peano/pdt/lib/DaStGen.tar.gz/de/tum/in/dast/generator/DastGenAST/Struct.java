// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.DastGenAST;

import java.util.ArrayList;

import de.tum.in.dast.generator.memberSelection.Member;

public class Struct implements AbstractNode {

	private String namespace;
	
	private String structName;
	
	/**
	 * the fields which have been defined in the data structure declaration.
	 * called virtual because they are not necessarily members of the c++-object
	 * but may exist only virtually.
	 * The virtual members are mapped to internal members (N:1) 
	 */
	private ArrayList<Member> virtualMembers = new ArrayList<Member>();
	
	/**
	 * The fields of the c++-class wich will be generated.
	 */
	private ArrayList<Member> internalMembers = new ArrayList<Member>();
	
	
	public Struct(String structName) {
		super();
		this.structName = structName;
	}
	
	public String getStructName() {
		return structName;
	}
	
	public void setNamespace(String ns) {
		this.namespace = ns;
	}
	
	public String getNamespace() {
		return namespace;
	}

	public void applyVisitor(Visitor visitor) {
		visitor.process(this);
	}

	public void addMember(Member member) {
		virtualMembers.add(member);
	}
	
	public ArrayList<Member> getVirtualMembers() {
		return virtualMembers;
	}
	
	public ArrayList<Member> getInternalMembers() {
		return internalMembers;
	}
	
}
