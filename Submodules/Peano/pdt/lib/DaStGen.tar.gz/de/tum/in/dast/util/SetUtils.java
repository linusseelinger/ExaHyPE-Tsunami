// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.util;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import de.tum.in.dast.generator.memberSelection.Member;


@SuppressWarnings("unchecked")
public class SetUtils {


	public static Set powerSetWithoutEmptyElement(final Set set) {
		Set result = powerSet(set);
		result.remove(new HashSet());
		return result;
	}
	
	/** The powerSet method should return a Set object
	 *  whose elements are exactly the subsets of v. */
	public static Set<Set> powerSet(final Set set) {
		Set<Set> result = new HashSet<Set>();
		
		if (set.isEmpty()) {
//			v is empty, so return the set with the 
//			empty set as its only element
			result.add( new HashSet() );
			return result;
		}
		
//		Pick an element x of v and find the power set of v-{x}.
//		Then p is the set of subsets of v not containing x.
		Object currentElement = set.iterator().next();
		set.remove(currentElement);
		Set<Set> powerSubSet = powerSet(set);
		
//		Build the power set of v by adding, for each s in p,
//		both s and s u {x} to result
		Iterator<Set> i = powerSubSet.iterator();
		while (i.hasNext())
		{
			Set s = i.next();   // get the next element of i
			Set t = new HashSet(s); //  make a new copy of s
			t.add(currentElement); // add x to t (but not to s)
//			add both s and t to the answer
			result.add(s);
			result.add(t);
		}
		return result;
	}
	
	public static void sort(ArrayList<Member> members, ArrayList<String> orderOfElements) {
		for (int i = 0; i < orderOfElements.size()-1; i++) {
			String name = orderOfElements.get(i);
			for (int j = i+1; j < orderOfElements.size(); j++) {
				String memberName = members.get(j).getMemberName();
				if (memberName.equals(name)) {
					Member tmp = members.get(i);
					members.set(i, members.get(j));
					members.set(j, tmp);
				}
			}
		}
	}


}
