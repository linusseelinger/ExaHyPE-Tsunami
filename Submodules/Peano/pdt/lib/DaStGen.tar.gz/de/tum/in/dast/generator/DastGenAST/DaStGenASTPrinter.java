// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.DastGenAST;

import java.util.Collection;
import java.util.List;

import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.util.DaStStringBuilder;

public class DaStGenASTPrinter extends Visitor {

	DaStStringBuilder builder = new DaStStringBuilder();
	
	@Override
	protected void classIn(Class classObject) {
		builder.appendAndIndent("class in: " + classObject.getNamespace() + " " + classObject.getClassname());
		builder.incrementAndIndent("DaStGenASTPrinter");
	}

	@Override
	protected void classOut(Class classObject) {
		
		List<Member> virtualMembers = classObject.getVirtualMembers();
		List<Member> internalMembers = classObject.getInternalMembers();
		
		for (Member m : virtualMembers) {
			builder.appendAndIndent("Virtual Member: " + m.toString());
		}
		
		for (Member m : internalMembers) {
			builder.appendAndIndent("technical Member: " + m.toString());
		}
		
		builder.decrementAndIndent(getClass().getName());
		builder.appendAndIndent("class out");
	}

	@Override
	protected void compilationUnitIn(CompilationUnit compilationUnit) {
		builder.append("compilationUnit in: name="+compilationUnit.getName());
		builder.incrementAndIndent("DaStGenASTPrinter");
	}

	@Override
	protected void compilationUnitOut(CompilationUnit compilationUnit) {		
		builder.decrementAndIndent(getClass().getName());
		builder.append("compilationUnit out");
    System.out.println(builder.toString());
	}

	@Override
	public void process(Include include) {
	    builder.append("Include: " + include.getInclude());
	    builder.indent();
	}

	@Override
	public void process(Enumeration enumeration) {
		builder.appendAndIndent("Enumeration: " + enumeration.getTypeString(false) + 
				" Values: " + enumeration.getValues());
	}

	@Override
	public void process(ConstantMember constantMember) {
		builder.appendAndIndent("Constant member: " + constantMember.getType() + 
				" " + constantMember.getIdentifier() +  
				" Value: " + constantMember.getValue());		
	}

	@Override
	public void process(FriendDeclaration friendDeclaration) {
		builder.appendAndIndent("Friend class: " + friendDeclaration.getFriend());
	}

	@Override
	public void process(Struct struct) {
		builder.append("STRUCT: " + struct.getStructName());
		builder.incrementAndIndent("DaStGenASTPrinter");
		
		List<Member> virtualMembers = struct.getVirtualMembers();
		List<Member> internalMembers = struct.getInternalMembers();
		
		for (Member m : virtualMembers) {
			builder.appendAndIndent("Virtual Member: " + m.toString());
		}
		
		for (Member m : internalMembers) {
			builder.appendAndIndent("technical Member: " + m.toString());
		}
		builder.decrementAndIndent(getClass().getName());
		builder.appendAndIndent("STRUCT out");
	}


	@Override
	protected void ifdefBranchIn(IfdefBranch ifdefBranch) {
		builder.append("IfdefBranch in: " + ifdefBranch.getConditions());
		builder.incrementAndIndent(getClass().getName());
	}

	@Override
	protected void ifdefBranchOut(IfdefBranch ifdefBranch) {
		builder.decrementAndIndent(getClass().getName());
		builder.appendAndIndent("IfdefBranch out: " + ifdefBranch.getConditions());
	}

	@Override
	protected void ifdefIn(Ifdef ifdef) {
		builder.append("Ifdef in: " + ifdef.getConditions());
		builder.incrementAndIndent("DaStGenASTPrinter");
	}

	@Override
	protected void ifdefOut(Ifdef ifdef) {
		builder.decrementAndIndent(getClass().getName());
		builder.appendAndIndent("Ifdef out: " + ifdef.getConditions());
	}

	@Override
	public void process(NamespaceDeclaration namespaceDeclaration) {
		builder.append("NamespaceDeclaration: " + namespaceDeclaration.getNamespace());
		builder.incrementAndIndent("DaStGenASTPrinter");
		builder.append("classes: " + namespaceDeclaration.getClassnames());
		builder.decrementAndIndent(getClass().getName());
	}
	

	public static void printMembers(Collection<Member> members) {
      System.out.println("In collection: ");
		  for (Member m: members) {
			  System.out.println("Member:" + m.toString());
		  }
	}

	@Override
	public void process(Typedef typedef) {
    System.out.println("Typedef: " + typedef.getType().getTypeString(true));
	}	
}
