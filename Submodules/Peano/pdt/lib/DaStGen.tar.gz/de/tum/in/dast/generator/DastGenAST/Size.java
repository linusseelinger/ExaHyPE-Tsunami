// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.DastGenAST;

import de.tum.in.dast.util.RangeCalculator;

/**
 * This class represents a size. In DaStGen definition files, a size is either 
 * specified as a number or as a preprocessor constant. Thus, a size deals with 
 * this dualism and is represented by a string as well by an int (if possible).
 * 
 * @author Wolfgang Eckhardt
 */
public class Size {
	
	// string value of the size
	private String stringRepresentation;
	// int value of the size
	private int size;

	/**
	 * Constructor used for preprocessor constants,
	 * where the name of the size is a string and the int size is 
	 * specified as a hint by the user
	 */
	public Size(String stringRepresentation, int size) {
		super();
		this.stringRepresentation = stringRepresentation;
		this.size = size;
	}
	
	public void doubleSize() {
	  size *= 2;
	}
	
	/**
	 * 
	 */
	public Size(String size) {
		this.stringRepresentation = size;
		try {
			this.size = Integer.parseInt(size);
		} catch (NumberFormatException nfe) {
			this.size = -1;
		}
	}
	
	/**
	 * 
	 */
	public Size(int size) {
		this.size = size;
		stringRepresentation = Integer.toString(size);
	}

	public String getStringRepresentation() {
		return stringRepresentation;
	}

	public int getSize() {
		return size;
	}
	
	public Size add(Size addend) {
		Size result = new Size(this.stringRepresentation, this.size);
		if (this.size > 0 && addend.size > 0) {
			result.size += addend.size;
		}
		result.stringRepresentation = RangeCalculator.getTotalBitSize(this.stringRepresentation + "+" + addend.stringRepresentation);
		return result;
	}
	
	/**
	 * @return true if this size is less than the parameter size
	 */
	public boolean lessOrEqual(Size other) {
		if (this.size < 0 || other.size < 0) {
			throw new RuntimeException("size not initialized to useful value! this: " + this + " other " + other);
		}
		
		return (this.size <= other.size);
	}
	
	@Override
	public boolean equals(Object otherObject) {
		if (otherObject == null || getClass() != otherObject.getClass()) {
			return false;
		}
		
		Size otherSize = (Size) otherObject;
		
		if (stringRepresentation == null && otherSize.stringRepresentation != null) {
			return false;
		}
		
		if (stringRepresentation != null) {
			if (!stringRepresentation.equals(otherSize.stringRepresentation)) {
				return false;
			}
		}
		
		return size == otherSize.size;
	}
	
	public String toString() {
		return "Size: " + getStringRepresentation() + " " + size;
	}
}
