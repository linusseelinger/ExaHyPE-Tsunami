// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.plugin;

import java.util.List;

import de.tum.in.dast.generator.DaStConfiguration;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.util.DaStStringBuilder;

/**
 * Exampleimplementation of the CodePlugin interface to demonstrate
 * its use.
 * 
 * @author Wolfgang Eckhardt
 */
public class ExamplePlugin implements CodePlugin {
	
	public void generateDefinition(DaStConfiguration configuration,
			DaStStringBuilder stringBuilder, String qualifiedClassName,
			List<Member> virtualMembers, List<Member> internalMembers) {
		stringBuilder.append("public: ");
		stringBuilder.incrementAndIndent(getClass().getName());
		stringBuilder.appendAndIndent("void hello();");
		stringBuilder.decrementAndIndent(getClass().getName());
	}

	public void generateImplementation(DaStConfiguration configuration,
			DaStStringBuilder stringBuilder, String qualifiedClassName,
			List<Member> virtualMembers, List<Member> internalMembers) {
		 stringBuilder.append("void "+qualifiedClassName+"::hello() {");
		 stringBuilder.incrementAndIndent(getClass().getName());
		 stringBuilder.append("std::cout << \"Hello from " +
		 		"the example-plugin!\" << std::endl; ");
		 stringBuilder.decrementAndIndent(getClass().getName());
		 stringBuilder.appendAndIndent("}");
		 stringBuilder.decrementAndIndent(getClass().getName());
	}

}
