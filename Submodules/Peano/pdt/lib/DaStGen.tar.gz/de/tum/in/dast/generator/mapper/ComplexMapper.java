package de.tum.in.dast.generator.mapper;

import de.tum.in.dast.generator.DaStConfiguration;
import de.tum.in.dast.generator.DastGenAST.Size;
import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.generator.naming.NameTranslator;
import de.tum.in.dast.generator.naming.NameTranslatorFactory;
import de.tum.in.dast.util.DaStStringBuilder;


/**
 * Complex Mapper
 * 
 * Handling complex numbers basically relies on the C++ std::complex data 
 * types. As this type hides the real and imaginary part of the numbers, the 
 * MPI mapping is kind of tricky and follows 
 * http://en.cppreference.com/w/cpp/numeric/complex:
 * 
 * reinterpret_cast<T*>(p)[2*i] is the real part of the complex number p[i], and 
 * reinterpret_cast<T*>(p)[2*i + 1] is the imaginary part of the complex number p[i]
 * 
 * @author Tobias Weinzierl
 * @see PeanoHeapSnippetGenerator
 */
public class ComplexMapper implements Mapper {

  protected Member member;
  protected NameTranslator translator = NameTranslatorFactory.getNameTranslator();
  protected Type type;

  public ComplexMapper(Member member, Type type) {
    this.member = member;
    this.type = type;
  }
  
  @Override
  public int getNumberOfOperations() {
    return 6;
  }

  @Override
  public void writeMethodSignature(
    int operationNumber,
    DaStStringBuilder builder
  ) {
    switch (operationNumber) {
    case 0:
      builder.append( getGetMethodSignature(false) );
      builder.append( ";" );
      break;
    case 1:
      builder.append( getSetMethodSignature(false) );
      builder.append( ";" );
      break;
    case 2:
      builder.append( getGetRealMethodSignature(false) );
      builder.append( ";" );
      break;
    case 3:
      builder.append( getGetImagMethodSignature(false) );
      builder.append( ";" );
      break;
    case 4:
      builder.append( getSetRealMethodSignature(false) );
      builder.append( ";" );
      break;
    case 5:
      builder.append( getSetImagMethodSignature(false) );
      builder.append( ";" );
      break;
    default: throw new RuntimeException( "Only operation 0-5 supported" );
  }
  }

  @Override
  public void writeMethodImplementation(int operationNumber,
      DaStStringBuilder builder) {
    switch (operationNumber) {
    case 0:
      getGetMethod(builder);
      break;
    case 1:
      getSetMethod(builder);
      break;
    case 2:
      getSetRealMethod(builder);
      break;
    case 3:
      getSetImagMethod(builder);
      break;
    case 4:
      getGetRealMethod(builder);
      break;
    case 5:
      getGetImagMethod(builder);
      break;
    default: throw new RuntimeException( "Only operation 0-5 supported" );
  }
  }

  @Override
  public void writeDeclaration(
    DaStStringBuilder builder,
    boolean currentClassIsPacked
  ) {
    builder.appendAndIndent(
      "std::complex<double> "
      +translator.getAttributeName(member.getMemberName())
      +";"
    );
  }

  @Override
  public String getMappedDataType() {
    return "std::complex<double>";
  }

  @Override
  public String getToString() {
    return "out << \""+member.getMemberName()+":\" << "
         + translator.getGetter(member.getMemberName())+"();";
  }

  @Override
  public Size getBitfieldLength() {
    return new Size(0);
  }

  @Override
  public Type getTypeObject() {
    return type;
  }

  @Override
  public void writeConstructorAssertions(DaStStringBuilder builder) {
    // No assertions to insert - do nothing.
  }

  @Override
  public String toString() {
    return getClass().getName();
  }
  
  private void getGetMethod(DaStStringBuilder builder) {
    builder.indent();
    builder.append(getGetMethodSignature(!DaStConfiguration.manuallyInline));
    builder.append(" {");
    builder.incrementAndIndent(getClass().getName());
    builder.append("return "+member.getMappedVariable()+";" );
    builder.decrementAndIndent(getClass().getName());
    builder.appendAndIndent("}");
  }

  private void getGetRealMethod(DaStStringBuilder builder) {
    builder.indent();
    builder.append(getGetRealMethodSignature(!DaStConfiguration.manuallyInline));
    builder.append(" {");
    builder.incrementAndIndent(getClass().getName());
    builder.append("return " + member.getMappedVariable()+".real();" );
    builder.decrementAndIndent(getClass().getName());
    builder.appendAndIndent("}");
  }

  private void getGetImagMethod(DaStStringBuilder builder) {
    builder.indent();
    builder.append(getGetImagMethodSignature(!DaStConfiguration.manuallyInline));
    builder.append(" {");
    builder.incrementAndIndent(getClass().getName());
    builder.append("return " + member.getMappedVariable()+".imag();" );
    builder.decrementAndIndent(getClass().getName());
    builder.appendAndIndent("}");
  }

  private void getSetMethod(DaStStringBuilder builder) {
    builder.indent();
    builder.append(getSetMethodSignature(!DaStConfiguration.manuallyInline));
    builder.append(" {");
    builder.incrementAndIndent(getClass().getName());
    builder.append(member.getMappedVariable()+" = " + translator.getArgumentName(member.getMemberName()) + ";" );
    builder.decrementAndIndent(getClass().getName());
    builder.appendAndIndent("}");
  }

  private void getSetRealMethod(DaStStringBuilder builder) {
    builder.indent();
    builder.append(getSetRealMethodSignature(!DaStConfiguration.manuallyInline));
    builder.append(" {");
    builder.incrementAndIndent(getClass().getName());
    builder.append(member.getMappedVariable()+".real(" + translator.getArgumentName(member.getMemberName()) + ");" );
    builder.decrementAndIndent(getClass().getName());
    builder.appendAndIndent("}");
  }

  private void getSetImagMethod(DaStStringBuilder builder) {
    builder.indent();
    builder.append(getSetImagMethodSignature(!DaStConfiguration.manuallyInline));
    builder.append(" {");
    builder.incrementAndIndent(getClass().getName());
    builder.append(member.getMappedVariable()+".imag(" + translator.getArgumentName(member.getMemberName()) + ");" );
    builder.decrementAndIndent(getClass().getName());
    builder.appendAndIndent("}");
  }

  private String getSetMethodSignature(boolean qualified) {
    String prefix             = "";
    String qualifiedClassName = "";
    String attributes         = "";
    if (DaStConfiguration.manuallyInline) {
      prefix += "inline";
    }
    if (qualified) {
      qualifiedClassName = member.getClassName() + "::";
    }
    if (DaStConfiguration.manuallyInline) {
      attributes += AttributeInline;
    }
    return prefix + " void " + qualifiedClassName + 
      translator.getSetter(member.getMemberName()) + 
      "(const std::complex<double>& "+
      translator.getArgumentName(member.getMemberName())+") " + attributes;
  }

  private String getSetRealMethodSignature(boolean qualified) {
    String prefix             = "";
    String qualifiedClassName = "";
    String attributes         = "";
    if (DaStConfiguration.manuallyInline) {
      prefix += "inline";
    }
    if (qualified) {
      qualifiedClassName = member.getClassName() + "::";
    }
    if (DaStConfiguration.manuallyInline) {
      attributes += AttributeInline;
    }
    return prefix + " void " + qualifiedClassName + 
      translator.getSetter(member.getMemberName()) + 
      "Real(const double& "+
      translator.getArgumentName(member.getMemberName())+") " + attributes;
  }


  private String getSetImagMethodSignature(boolean qualified) {
    String prefix             = "";
    String qualifiedClassName = "";
    String attributes         = "";
    if (DaStConfiguration.manuallyInline) {
      prefix += "inline";
    }
    if (qualified) {
      qualifiedClassName = member.getClassName() + "::";
    }
    if (DaStConfiguration.manuallyInline) {
      attributes += AttributeInline;
    }
    return prefix + " void " + qualifiedClassName + 
      translator.getSetter(member.getMemberName()) + 
      "Imag(const double& "+
      translator.getArgumentName(member.getMemberName())+") " + attributes;
  }

  private String getGetMethodSignature(boolean qualified) {
    String prefix             = "";
    String qualifiedClassName = "";
    String attributes         = "";
    if (DaStConfiguration.manuallyInline) {
      prefix += "inline";
    }
    if (qualified) {
      qualifiedClassName = member.getClassName() + "::";
    }
    if (DaStConfiguration.manuallyInline) {
      attributes += AttributeInline;
    }
    return prefix + " std::complex<double> " + qualifiedClassName +
        translator.getGetter(member.getMemberName())+"() const " + attributes;
  }

  private String getGetRealMethodSignature(boolean qualified) {
    String prefix             = "";
    String qualifiedClassName = "";
    String attributes         = "";
    if (DaStConfiguration.manuallyInline) {
      prefix += "inline";
    }
    if (qualified) {
      qualifiedClassName = member.getClassName() + "::";
    }
    if (DaStConfiguration.manuallyInline) {
      attributes += AttributeInline;
    }
    return prefix + " double " + qualifiedClassName +
        translator.getGetter(member.getMemberName())+"Real() const " + attributes;
  }


  private String getGetImagMethodSignature(boolean qualified) {
    String prefix             = "";
    String qualifiedClassName = "";
    String attributes         = "";
    if (DaStConfiguration.manuallyInline) {
      prefix += "inline";
    }
    if (qualified) {
      qualifiedClassName = member.getClassName() + "::";
    }
    if (DaStConfiguration.manuallyInline) {
      attributes += AttributeInline;
    }
    return prefix + " double " + qualifiedClassName +
        translator.getGetter(member.getMemberName())+"Imag() const " + attributes;
  }


	
	@Override
  public boolean passObjectsInConstructorViaConstReference() {
  	return true;
  }
}
