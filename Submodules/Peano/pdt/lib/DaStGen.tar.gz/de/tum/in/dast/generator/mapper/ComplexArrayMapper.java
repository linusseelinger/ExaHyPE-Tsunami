package de.tum.in.dast.generator.mapper;

import de.tum.in.dast.generator.DaStConfiguration;
import de.tum.in.dast.generator.DastGenAST.Size;
import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.generator.naming.NameTranslator;
import de.tum.in.dast.generator.naming.NameTranslatorFactory;
import de.tum.in.dast.util.DaStStringBuilder;

public class ComplexArrayMapper implements Mapper {

  protected Member member;
  protected Type type;
  protected NameTranslator translator = NameTranslatorFactory.getNameTranslator();

  public ComplexArrayMapper(Member member, Type type) {
    this.type = type;
    this.member = member;
  }
  
  @Override
  public int getNumberOfOperations() {
    return 4;
  }

  @Override
  public void writeMethodSignature(int operationNumber,
      DaStStringBuilder builder) {
    switch (operationNumber) {
      case 0:
        builder.append( getGetMethodSignature(false) );
        builder.append( ";" );
        break;
      case 1:
        builder.append( getSetMethodSignature(false) );
        builder.append( ";" );
        break;
      case 2:
        builder.append( getGetElementMethodSignature(false) );
        builder.append( ";" );
        break;
      case 3:
        builder.append( getSetElementMethodSignature(false) );
        builder.append( ";" );
        break;
      default: throw new RuntimeException( "Only operation 0 to 3 supported" );
    }
  }

  @Override
  public void writeMethodImplementation(
    int operationNumber,
    DaStStringBuilder builder
  ) {
    switch (operationNumber) {
      case 0:
        getGetMethod(builder);
        break;
      case 1:
        getSetMethod(builder);
        break;
      case 2:
        getGetElementMethod(builder);
        break;
      case 3:
        getSetElementMethod(builder);
        break;
      default: throw new RuntimeException( "Only operation 0 through 3 supported" );
    }
  }
  
  private String getArrayTypeNameForPublicSignature() {
    return translator.getArrayDataType(
             new Type("std::complex<double> ",""), 
             member.getArraySize().getStringRepresentation()
           ).getTypeString(false);    
  }

  
  private String getArrayTypeNameForInternalSignature() {
    return translator.getArrayDataType(
             new Type("std::complex<double> ",""), 
             member.getArraySize().getStringRepresentation()
           ).getTypeString(false);    
  }

  @Override
  public void writeDeclaration(
    DaStStringBuilder builder,
    boolean currentClassIsPacked
  ) {
    String declarationWithoutSemicolon = 
        getArrayTypeNameForInternalSignature()
        + " " + 
       translator.getAttributeName(member.getMemberName());
 
    if (DaStConfiguration.manuallyAlign && !currentClassIsPacked) {
      builder.appendAndIndent( "#ifdef " + translator.getCFVectorAlignment() );
      builder.append( declarationWithoutSemicolon );
      builder.appendAndIndent( " __attribute__((aligned(VectorisationAlignment)));"  );
      builder.appendAndIndent( "#else" );
      builder.appendAndIndent( declarationWithoutSemicolon + ";");
      builder.appendAndIndent( "#endif" );
    }
    else {
      builder.appendAndIndent( declarationWithoutSemicolon + ";");
    }
  }

  @Override
  public String getMappedDataType() {
    return type.getTypeString(false).replace(Type.COMPLEX, "std::complex<double> ");
  }
  

  @Override
  public String getToString() {
    return "out << \""+member.getMemberName()+":\" << "
        + translator.getGetter(member.getMemberName())+"();";
  }

  @Override
  public Size getBitfieldLength() {
    return new Size(0);
  }

  @Override
  public Type getTypeObject() {
    return type;
  }

  @Override
  public void writeConstructorAssertions(DaStStringBuilder builder) {
    // No assertions to insert - do nothing.
  }
  
  private void getGetMethod(DaStStringBuilder builder) {
    builder.indent();
    builder.append(getGetMethodSignature(!DaStConfiguration.manuallyInline) + " {");
    builder.incrementAndIndent(getClass().getName());
    builder.appendAndIndent( getArrayTypeNameForPublicSignature() + " result;" );
    builder.append( 
        "for( int i=0; i<" + member.getMappedVariable() +
        ".size(); i++) {");
      builder.incrementAndIndent(getClass().getName());
      builder.append( 
        "result[i] = " + member.getMappedVariable() + "[i];"
      );
      builder.decrementAndIndent(getClass().getName());
      builder.appendAndIndent("}");
    builder.append( "return result;" );
    builder.decrementAndIndent(getClass().getName());
    builder.appendAndIndent("}");
  }

  private void getSetMethod(DaStStringBuilder builder) {
    builder.indent();
    builder.append(getSetMethodSignature(!DaStConfiguration.manuallyInline) + " {");
    builder.incrementAndIndent(getClass().getName());
    builder.append( 
      "for( int i=0; i<" + translator.getArgumentName(member.getMemberName()) +
      ".size(); i++) {");
    builder.incrementAndIndent(getClass().getName());
    builder.appendAndIndent( 
      member.getMappedVariable() + "[i] = " +
      translator.getArgumentName(member.getMemberName()) + " [i];"
    );
    builder.decrementAndIndent(getClass().getName());
    builder.append("}");
    builder.decrementAndIndent(getClass().getName());
    builder.appendAndIndent("}");
  }

  private void getGetElementMethod(DaStStringBuilder builder) {
    builder.indent();
    builder.append(getGetElementMethodSignature(!DaStConfiguration.manuallyInline) + " {");
    builder.incrementAndIndent(getClass().getName());
    builder.appendAndIndent( 
      "return " + member.getMappedVariable() + "[elementIndex];" 
    );
    builder.decrementAndIndent(getClass().getName());
    builder.appendAndIndent("}");
  }

  private void getSetElementMethod(DaStStringBuilder builder) {
    builder.indent();
    builder.append(getSetElementMethodSignature(!DaStConfiguration.manuallyInline) + " {");
    builder.incrementAndIndent(getClass().getName());
    builder.appendAndIndent( 
      member.getMappedVariable() + "[elementIndex] = " +
      translator.getArgumentName(member.getMemberName()) + ";"
    );
    builder.decrementAndIndent(getClass().getName());
    builder.appendAndIndent("}");
  }

  private String getGetElementMethodSignature(boolean qualified) {
    String prefix             = "";
    String qualifiedClassName = "";
    String attributes         = "";
    if (DaStConfiguration.manuallyInline) {
      prefix += "inline";
    }
    if (qualified) {
      qualifiedClassName = member.getClassName() + "::";
    }
    if (DaStConfiguration.manuallyInline) {
      attributes += AttributeInline;
    }
    return 
      prefix + 
      " std::complex<double> " + 
      qualifiedClassName 
      + translator.getGetter(member.getMemberName())+"(int elementIndex) const" 
      + " "
      + attributes;
  }

  private String getSetElementMethodSignature(boolean qualified) {
    String prefix             = "";
    String qualifiedClassName = "";
    String attributes         = "";
    if (DaStConfiguration.manuallyInline) {
      prefix += "inline";
    }
    if (qualified) {
        qualifiedClassName = member.getClassName() + "::";
      }
    if (DaStConfiguration.manuallyInline) {
      attributes += AttributeInline;
    }
    return   prefix 
             + " void " 
             + qualifiedClassName 
             + translator.getSetter(member.getMemberName()) 
             + "(int elementIndex, const std::complex<double>& " 
             + translator.getArgumentName(member.getMemberName())+")"
             + " "
             + attributes;
  }

  private String getSetMethodSignature(boolean qualified) {
    String prefix             = "";
    String qualifiedClassName = "";
    String attributes         = "";
    if (DaStConfiguration.manuallyInline) {
      prefix += "inline";
    }
    if (qualified) {
      qualifiedClassName = member.getClassName() + "::";
    }
    if (DaStConfiguration.manuallyInline) {
      attributes += AttributeInline;
    }
    return prefix + 
           " void " + qualifiedClassName + 
      translator.getSetter(member.getMemberName()) + 
      "(const "+ getArrayTypeNameForPublicSignature()+"& "+translator.getArgumentName(member.getMemberName())+")"
      + " "
      + attributes;
  }
    
  private String getGetMethodSignature(boolean qualified) {
      String prefix             = "";
      String qualifiedClassName = "";
      String attributes         = "";
      if (DaStConfiguration.manuallyInline) {
        prefix += "inline";
      }
      if (qualified) {
        qualifiedClassName = member.getClassName() + "::";
      }
      if (DaStConfiguration.manuallyInline) {
        attributes += AttributeInline;
      }
      return prefix 
             + " "
             + getArrayTypeNameForPublicSignature()
             + " "
             + qualifiedClassName 
             + translator.getGetter(member.getMemberName())+"() const"
             + " " 
             + attributes
             ;
  }
  

	
	@Override
  public boolean passObjectsInConstructorViaConstReference() {
  	return true;
  }

}
