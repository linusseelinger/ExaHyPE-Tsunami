// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.naming;

import de.tum.in.dast.generator.DastGenAST.Type;

/**
 * Interface for NameTranslators. A NameTranslator takes a 
 * member name and generates the name for get- and setMethods as
 * well as the variable name itself, according to naming-conventions.
 *
 * @author Wolfgang Eckhardt
 */
public interface NameTranslator {

	/**
	 * generates the name of the getMethod for a given member
	 * 
	 * @param name the name of the member to generate the name of
	 * 			   		the getMethod
	 * @return the name of the getMethod
	 */
	public String getGetter(String name);

	public String getBitArrayFlipOperationName(String name);

	/**
	 * generates the name of the setMethod for a given member
	 * 
	 * @param name the name of the member to generate the name of
	 * 			   		the setMethod
	 * @return the name of the setMethod
	 */
	public String getSetter(String name);
	
	/**
	 * generates the variable name of a given member
	 * 
	 * @param name the name of the member for which the name should
	 * 					be generated
	 * @return the name of the variable
	 */
	public String getAttributeName(String name);
	
	/**
	 * generates the name of the parameter for set-method and constructor 
	 * for this member. Return values must be different for different argument values.
	 * 
	 * @param name the name of the member
	 * @return the name of the argument 
	 */
	public String getArgumentName(String name);
	
	
	/**
	 * generates the name of the include-guard for the headerfile
	 * of the declared class.
	 * 
	 * @param className the fully qualified name of the class which is to be declared
	 * @return the name of the include-guard
	 */
	public String getIncludeGuard(String className);
	
	/**
	 * @return the path, where the include-files of the defined classes
	 * 			 are stored. This path is only used in implementation files
	 * 			 as prefix of the included filename. If the return value isn't equal the
	 * 			 empty string "", it has to be terminated by the pathseperator "/". 
	 */
	public String getIncludePath(String qualifiedClassName);
	
	/**
	 * @return the name of the struct Persistent_Records
	 */
	public String getPersistentRecords();
	
	/**
	 * @return the name of the assert(bool-expr) macro. Used in setter and constructor
	 * 			of classes with packed fields.
	 */
	public String getAssertion();
	
	/**
	 * This operation defines which includes are added to the header file.
	 * 
	 * @return an array containing the complete include instruction, 
	 * 			e.g. {"#include \"usr/myInclude\", include \"usr/yourInclude\,
	 * 					#include <iostream>, #include <bitset>"}
	 */
	public String[] getIncludes();
	
	/**
	 * @return the name of the compiler flag for Packed_Records
	 * @see getCFParallel();
	 */
	public String getCFPackedRecords();
	
	public String getCFVectorAlignment();
	

	/**
	 * @return the classname for the packed class type.
	 */
	public String getClassnameForPackedClass(String classname);
	
	/**
	 *
	 * @return the classname for the unpacked class type.
	 */
	public String getClassnameForFlatClass(String classname);

	/**
	 * return a type object, which describes arrays of the type specified
	 * by the typeobject.
	 * 
	 * TODO more description on how to implement a costum type object  
	 * 
	 * @param typeObject
	 * @return
	 */
	public Type getArrayDataType(Type typeObject, String arrayLength);
	
	public boolean isDestructorVirtual();
}
