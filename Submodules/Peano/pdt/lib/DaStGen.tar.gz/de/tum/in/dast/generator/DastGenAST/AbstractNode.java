// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.DastGenAST;

/**
 * This class represents an abstract element of the abstract syntax tree.
 * It is intended to be used as 
 * 
 * @author Wolfgang Eckhardt
 */
public interface AbstractNode {

	public abstract void applyVisitor(Visitor visitor);
	
}
