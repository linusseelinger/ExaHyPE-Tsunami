// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.packing;

import java.util.List;

import de.tum.in.dast.generator.DastGenAST.Type;
import de.tum.in.dast.generator.memberSelection.Member;

/**
 * Interface for Packers, which pack a number of variables 
 * into a single bitfield
 * 
 * @author Wolfgang Eckhardt
 *
 */
public interface Packer {
	
	public static final String FIELD_PACKED_RECORDS = "_packed_records";

	/**
	 * packs the members into a single variable
	 * 
	 * @param members the members to be packed
	 */
	public void pack(List<Member> virtualMembers,
			List<Member> technicalMembers, Type bitfieldType);

}
