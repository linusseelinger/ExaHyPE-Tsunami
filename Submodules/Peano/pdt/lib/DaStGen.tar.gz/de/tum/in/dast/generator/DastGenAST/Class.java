// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.DastGenAST;

import java.util.ArrayList;
import java.util.TreeMap;

import de.tum.in.dast.generator.memberSelection.Member;
import de.tum.in.dast.generator.naming.NameTranslatorFactory;

/**
 * Represents a class object, which is nested in a compilation unit.
 * 
 * @author Wolfgang Eckhardt
 */
public class Class implements AbstractNode {

	/** the simple classname */
	private String classname = null;
	
	/** the classname of the other alternative */
	private String dualClassname = null;
	
	/** the namespace this class lives in */
	private String namespace = null;
	
	private boolean isPacked = false;
	
	private TreeMap<String, Enumeration> enumerations = new TreeMap<String, Enumeration>();
	
	private ArrayList<Typedef> enumTypedefs = new ArrayList<Typedef>();
	private ArrayList<Typedef> typedefs = new ArrayList<Typedef>();
	
	private ArrayList<FriendDeclaration> friends = new ArrayList<FriendDeclaration>();
	
	/**
	 * the fields which have been defined in the data structure declaration.
	 * called virtual because they are not necessarily members of the c++-object
	 * but may exist only virtually.
	 * The virtual members are mapped to internal members (N:1) 
	 */
	private ArrayList<Member> virtualMembers = new ArrayList<Member>();
	
	/**
	 * The fields of the c++-class wich will be generated.
	 */
	private ArrayList<Member> internalMembers = new ArrayList<Member>();
	
	/**
	 * This list contains all constant members of the c++-class that will be generated.
	 */
	private ArrayList<ConstantMember> constantMembers = new ArrayList<ConstantMember>();
	
	private Struct struct;
	
	private boolean needsPragmas = false;
	
	public Class() {
		super();
		String structName = NameTranslatorFactory.getNameTranslator().getPersistentRecords();
		struct = new Struct(structName);
	}

	public void initialize(String namespace, String classname, String dualClassname, boolean isPacked) {
		if (this.classname != null || this.namespace != null || this.dualClassname != null) {
			throw new RuntimeException("Error: duplicate initialization of class object! arguments: "
					+ namespace + " " + classname);
		}
		this.classname     = classname;
		this.namespace     = namespace;	
		this.dualClassname = dualClassname;
		this.isPacked      = isPacked;
		
		if ("".equals(namespace)) {
			struct.setNamespace(classname);
		} else {
			struct.setNamespace(namespace + "::" + classname);
		}
	}
	
	public void applyVisitor(Visitor visitor) {
		visitor.process(this);
	}
	
	public String getClassname() {
		return classname;
	}
	
	public String getDualClassname() {
		return dualClassname;
	}
	
	public String getNamespace() {
		return namespace;
	}
	
	public void addFriendDeclaration(FriendDeclaration friend) {
		friends.add(friend);
	}

	public void addEnumeration(Enumeration enumeration) {
		enumerations.put(enumeration.getTypeString(false), enumeration);
	}

	public Enumeration getEnumeration(String typename) {
		return enumerations.get(typename);
	}
	
	public TreeMap<String,Enumeration> getEnumerations() {
		return enumerations;
	}

	public ArrayList<FriendDeclaration> getFriends() {
		return friends;
	}
	
	public void addMember(Member member) {
		virtualMembers.add(member);
	}
	
	public ArrayList<Member> getVirtualMembers() {
		return virtualMembers;
	}
	
	public ArrayList<Member> getInternalMembers() {
		return internalMembers;
	}
	
	public void addConstantMember(ConstantMember constantMember){
		constantMembers.add(constantMember);
	}
	
	public ArrayList<ConstantMember> getConstantMembers(){
		return constantMembers;
	}
	
	public Struct getStruct() {
		return struct;
	}

	/**
	 * 
	 * @return This class needs pragmas, i.e. is the packed class plus pragmas 
	 *         are switched on.
	 */
	public boolean needsPragmas() {
		return needsPragmas;
	}

	public boolean isPacked() {
	  return isPacked;
	}
	
	public void setNeedsPragmas(boolean needsPragmas) {
		this.needsPragmas = needsPragmas;
	}

	public void addTypedef(Typedef typedef) {
		typedefs.add(typedef);
	}
	
	public void addEnumTypedef(Typedef typedef) {
		enumTypedefs.add(typedef);
	}
	
	public ArrayList<Typedef> getEnumTypedefs() {
		return enumTypedefs;
	}
	
	public ArrayList<Typedef> getTypedefs() {
		return typedefs;
	}
	
	
}
