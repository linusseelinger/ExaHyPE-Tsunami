// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.DastGenAST;

import java.util.ArrayList;

public class NamespaceDeclaration implements AbstractNode {

	private String namespace;
	
	private ArrayList<String> classnames = new ArrayList<String>();
	
	public NamespaceDeclaration(String namespace) {
		this.namespace = namespace;
	}
	
	public void addClassname(String classname) {
		classnames.add(classname);
	}
	
	public String getNamespace() {
		return namespace;
	}

	public ArrayList<String> getClassnames() {
		return classnames;
	}
	
	public void applyVisitor(Visitor visitor) {
		visitor.process(this);
	}

}
