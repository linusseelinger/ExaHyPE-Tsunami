// Copyright (C) 2009 Technische Universitaet Muenchen
// This file is part of the DaStGen project. For conditions of distribution and
// use, please see the copyright notice at https://sourceforge.net/p/dastgen
package de.tum.in.dast.generator.naming;

import de.tum.in.dast.generator.DastGenAST.Type;

public class StdBitsetType extends Type {

	private String length;
	
	public StdBitsetType(String type, String qualification, String length) {
		super(type, qualification);
		this.length = length;
	}

	public String getTypeString(boolean qualified) {
		return "std::bitset<" + length + ">";
	}
	
}
